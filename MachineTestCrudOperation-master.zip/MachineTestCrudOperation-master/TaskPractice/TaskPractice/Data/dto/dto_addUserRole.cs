﻿namespace TaskPractice.Data.dto
{
    public class dto_addUserRole
    {
        public int UserId { get; set; }
        public List<int> RoleIds { get; set; }
    }
}
