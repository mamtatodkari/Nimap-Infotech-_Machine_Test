﻿namespace TaskPractice.Data.dto
{
    public class dto_Role
    {
        public string Name { get; set; } = string.Empty;
        public string RoleDescription { get; set; } = string.Empty;
    }
}
