﻿namespace TaskPractice.Data.dto
{
    public class dto_Category
    {
        public string ?CategoryName { get; set; }
    }
}
