﻿namespace TaskPractice.Data.dto
{
    public class dto_UpdateCategory
    {
        public int CategoryId { get; set; }
        public string CategoryName { get; set; }
    }
}
