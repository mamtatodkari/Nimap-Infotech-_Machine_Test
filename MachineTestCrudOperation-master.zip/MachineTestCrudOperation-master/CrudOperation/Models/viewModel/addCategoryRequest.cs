﻿namespace CrudOperation.Models.viewModel
{
    public class addCategoryRequest
    {
        public string? CategoryName { get; set; }
    }
}
