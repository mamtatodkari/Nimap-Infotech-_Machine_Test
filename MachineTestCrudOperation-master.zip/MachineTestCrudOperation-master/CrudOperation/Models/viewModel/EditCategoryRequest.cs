﻿namespace CrudOperation.Models.viewModel
{
    public class EditCategoryRequest
    {
        public int CategoryId { get; set; }
        public string? CategoryName { get; set; }
    }
}
