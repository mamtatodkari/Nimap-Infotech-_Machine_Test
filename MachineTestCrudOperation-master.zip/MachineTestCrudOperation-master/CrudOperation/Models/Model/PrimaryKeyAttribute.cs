﻿
namespace CrudOperation.Models.Model
{
    internal class PrimaryKeyAttribute : Attribute
    {
    }
}