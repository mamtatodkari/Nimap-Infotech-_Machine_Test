This is crud operation where Two Table present one is Category and other is Product and a product belongs to a category and also I have done pagination .
